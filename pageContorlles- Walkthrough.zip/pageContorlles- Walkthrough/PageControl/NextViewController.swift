//
//  NextViewController.swift
//  PageControl
//
//  Created by Mac on 24/12/20.
//  Copyright © 2020 Maor Shams. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
