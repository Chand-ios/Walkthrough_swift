//
//  PhotoVC.swift
//  UIPageViewController Post
//
//  Created by Maor Shams on 05/05/2017.
//  Copyright © 2017 Maor Shams. All rights reserved.
//

import UIKit

class PageViewController: UIViewController {
    
    @IBOutlet weak var nextbtn: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var containerView: UIView!
    
    var pageViewVC: PageViewVC? {
        didSet {
            pageViewVC?.pageViewDelegate = self
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pageControl.addTarget(self, action: #selector(didChangePageControlValue), for: .valueChanged)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destVC = segue.destination as? PageViewVC {
            self.pageViewVC = destVC
        }
    }
    
    // When the user taps on the pageControl to change its current page.
    @objc func didChangePageControlValue() {
        pageViewVC?.scrollTo(index: pageControl.currentPage)
    }
    
    
    @IBAction func nextAction(_ sender: Any) {
        
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let homeVC = sb.instantiateViewController(withIdentifier: "HomeNavigation")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = homeVC
        
       // let navigation = self.storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
      //  self.navigationController?.pushViewController(navigation, animated: true)
    }
    
}

extension PageViewController: PageViewVCDelegate {
    // number of pages
    func didUpdatePageCount(_ vc: PageViewVC, count: Int) {
        pageControl.numberOfPages = count
    }
    // current page
    func didUpdatePageIndex(_ vc: PageViewVC, index: Int) {
        
        if index == 3 {
            nextbtn.setTitle("NEXT", for: .normal)
        } else {
            nextbtn.setTitle("SKIP", for: .normal)
        }
        
        pageControl.currentPage = index
        print(index)
    }
}
