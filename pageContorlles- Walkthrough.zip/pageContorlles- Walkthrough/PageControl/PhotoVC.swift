//
//  PhotoVC.swift
//  UIPageViewController Post
//
//  Created by Maor Shams on 05/05/2017.
//  Copyright © 2017 Maor Shams. All rights reserved.
//

import UIKit

class PhotoVC: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
   // @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var subttileLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    var photoName : String!
    var titleName : String!
    var subtitleName : String!
    var nextName : String!
    var photoIndex: Int?
    var page: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        if photoIndex == 3 {
//            self.nextBtn.setTitle("NEXT", for: .normal)
//        } else {
//            self.nextBtn.setTitle("SKIP", for: .normal)
//
//        }
        
        if let photoName = photoName{
            self.imageView.image = UIImage(named: photoName)
            self.titleLbl.text = titleName
            self.subttileLbl.text = subtitleName
        }
    }
    
    
    
    @IBAction func nextAction(_ sender: Any) {
    }
}
